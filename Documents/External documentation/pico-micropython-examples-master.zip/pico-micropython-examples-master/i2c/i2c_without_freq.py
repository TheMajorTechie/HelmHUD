from machine import I2C

i2c = I2C(0)  # defaults to SCL=Pin(9), SDA=Pin(8), freq=400000
